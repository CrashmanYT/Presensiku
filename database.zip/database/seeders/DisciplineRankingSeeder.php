<?php

namespace Database\Seeders;

use App\Models\DisciplineRanking;
use Illuminate\Database\Seeder;

class DisciplineRankingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DisciplineRanking::factory()->count(20)->create();
    }
}