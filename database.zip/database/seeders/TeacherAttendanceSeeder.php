<?php

namespace Database\Seeders;

use App\Models\TeacherAttendance;
use Illuminate\Database\Seeder;

class TeacherAttendanceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        TeacherAttendance::factory()->count(100)->create();
    }
}