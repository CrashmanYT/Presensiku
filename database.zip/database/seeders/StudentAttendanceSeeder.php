<?php

namespace Database\Seeders;

use App\Models\StudentAttendance;
use Illuminate\Database\Seeder;

class StudentAttendanceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Generate 100 dummy student attendance records
        // Each record will create a new student and device via their factories
        StudentAttendance::factory()->count(100)->create();
    }
}